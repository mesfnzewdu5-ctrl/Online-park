# Online Park V1.5 — Uploadable Production Foundation

This package replaces the previous incomplete static prototype with a single deployable Node/Express application that serves the frontend and protected API, while Supabase remains the database/authentication service.

## Included
- Responsive frontend in `public/`
- Supabase Auth signup/login/reset/logout
- Public park catalog loaded from Supabase
- Protected search creation endpoint
- Server-side Supabase admin client for trusted writes
- RLS schema and seed data
- Rate limiting, Helmet and CORS
- Runtime injection of only the Supabase publishable key
- Server-only service-role and payment secrets
- Chapa payment integration starter, disabled until real server secrets are configured
- Health endpoint: `/api/health`

## 1. Supabase
1. Open your existing Supabase project.
2. Run `supabase/schema.sql` in SQL Editor.
3. Run `supabase/seed.sql`.
4. Confirm Authentication > Providers > Email is configured as you want.
5. Keep your existing RLS policies if they are already correct; review the resulting policies after applying this schema.

## 2. Local/server configuration
Copy `.env.example` to `.env` and fill in:
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

Do not put the service-role key in `public/` or any browser JavaScript.

## 3. Run
```bash
npm install
npm start
```
Open `http://localhost:3000`.

## 4. Production deployment
This is designed as one Node service: the server hosts both the frontend and API. Set the same environment variables in your hosting provider's secret/environment-variable settings, then deploy the repository.

Set `PUBLIC_BACKEND_URL` and `PUBLIC_FRONTEND_URL` to your final HTTPS domain when payment callbacks are enabled.

## 5. Payment
The Chapa integration is a server-side starter. Do not put the secret key in the frontend. Before accepting real payments, configure the provider account, webhook URL, HTTPS domain, and provider-specific webhook signing/verification requirements. Test in the provider's sandbox first.

## 6. Security
Supabase RLS must remain enabled on exposed tables. The publishable key can be used in the browser when RLS and least-privilege policies are correctly configured. Service-role/secret keys must stay server-side.

## Important
The app is uploadable/deployable, but a real payment provider account and your own production Supabase credentials are still required for live transactions. This package does not contain those secrets.
