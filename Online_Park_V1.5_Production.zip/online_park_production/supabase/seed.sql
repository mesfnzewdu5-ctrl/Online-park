insert into public.parks(name,slug,description) values
('Bahir Dar Lakeside Park','bahir-dar-lakeside','A lakeside discovery experience inspired by Lake Tana and Bahir Dar.'),
('Addis City Park','addis-city-park','An urban park experience for learning, culture and recreation.'),
('Green Valley Park','green-valley','A calm green space for outdoor activities and community experiences.')
on conflict(slug) do update set name=excluded.name, description=excluded.description;

insert into public.activities(park_id,name,description)
select p.id,'Nature walk','Explore the park environment at your own pace.' from public.parks p where p.slug='bahir-dar-lakeside'
and not exists(select 1 from public.activities a where a.park_id=p.id and a.name='Nature walk');
insert into public.activities(park_id,name,description)
select p.id,'Cultural discovery','Discover local culture and educational experiences.' from public.parks p where p.slug='addis-city-park'
and not exists(select 1 from public.activities a where a.park_id=p.id and a.name='Cultural discovery');
insert into public.activities(park_id,name,description)
select p.id,'Family recreation','Find simple activities for a shared day outdoors.' from public.parks p where p.slug='green-valley'
and not exists(select 1 from public.activities a where a.park_id=p.id and a.name='Family recreation');
