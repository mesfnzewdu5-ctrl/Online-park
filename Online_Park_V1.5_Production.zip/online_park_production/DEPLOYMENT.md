# Online Park V1.5 deployment checklist

1. Create a Git repository and upload this folder.
2. Deploy it as a Node.js web service.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables from `.env.example` in the hosting dashboard.
6. After deployment, open `/api/health` and confirm `{ "ok": true }`.
7. Open the main site and confirm parks load.
8. Test signup/login.
9. Test creating a search while signed in.
10. Run the Supabase policy verification query again after schema changes.
11. Only after all tests pass should you configure a real payment provider.

Never commit `.env` or any service-role/payment secret.
