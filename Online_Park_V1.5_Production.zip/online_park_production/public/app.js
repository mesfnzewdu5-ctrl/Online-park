const cfg = window.ONLINE_PARK_CONFIG || {};
const { createClient } = window.supabase;
const supabase = createClient(cfg.supabaseUrl, cfg.supabasePublishableKey);
let parks = [];

const $ = (id) => document.getElementById(id);
const show = (el, msg, kind = "") => { el.className = `result ${kind}`; el.classList.remove("hidden"); el.textContent = msg; };

async function loadParks() {
  const grid = $("parkGrid");
  grid.innerHTML = "<p class='muted'>Loading parks…</p>";
  const { data, error } = await supabase.from("parks").select("id,name,slug,description").order("name");
  if (error) { grid.innerHTML = "<p class='muted'>Could not load parks. Check the Supabase schema and policies.</p>"; return; }
  parks = data || [];
  $("parkCount").textContent = `${parks.length} park${parks.length === 1 ? "" : "s"}`;
  $("parkSelect").innerHTML = '<option value="">Any park</option>' + parks.map(p => `<option value="${p.id}">${escapeHtml(p.name)}</option>`).join("");
  grid.innerHTML = parks.length ? parks.map(p => `<article class="card park-card"><span class="park-tag">Park</span><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.description || "Discover activities and experiences in this park.")}</p><a class="button secondary" href="#search" data-park="${p.id}">Search this park</a></article>`).join("") : "<p class='muted'>No parks have been added yet.</p>";
  grid.querySelectorAll("[data-park]").forEach(a => a.addEventListener("click", () => { $("parkSelect").value = a.dataset.park; }));
}

function escapeHtml(value) { return String(value).replace(/[&<>\"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c])); }

async function refreshAccount() {
  const { data: { session } } = await supabase.auth.getSession();
  const status = $("accountStatus");
  if (session?.user) {
    status.className = "status success";
    status.textContent = `Signed in as ${session.user.email}`;
    $("logoutBtn").classList.remove("hidden");
  } else {
    status.className = "status";
    status.textContent = "Not signed in";
    $("logoutBtn").classList.add("hidden");
  }
}

$("signupForm").addEventListener("submit", async e => {
  e.preventDefault();
  const { error } = await supabase.auth.signUp({
    email: $("signupEmail").value.trim(), password: $("signupPassword").value,
    options: { data: { full_name: $("signupName").value.trim() } }
  });
  if (error) return alert(error.message);
  alert("Account created. Check your email if email confirmation is enabled.");
  e.target.reset(); refreshAccount();
});

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const { error } = await supabase.auth.signInWithPassword({ email: $("loginEmail").value.trim(), password: $("loginPassword").value });
  if (error) return alert(error.message);
  e.target.reset(); refreshAccount();
});

$("resetBtn").addEventListener("click", async () => {
  const email = prompt("Enter your account email:");
  if (!email) return;
  const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${location.origin}/#account` });
  alert(error ? error.message : "Password-reset instructions have been sent if the account exists.");
});

$("logoutBtn").addEventListener("click", async () => { await supabase.auth.signOut(); refreshAccount(); });
supabase.auth.onAuthStateChange(() => refreshAccount());

$("searchForm").addEventListener("submit", async e => {
  e.preventDefault();
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) { show($("searchResult"), "Please sign in before creating a search.", "error"); return; }
  const body = { query: $("searchQuery").value.trim() };
  if ($("parkSelect").value) body.park_id = $("parkSelect").value;
  const response = await fetch("/api/search", { method:"POST", headers:{"Content-Type":"application/json",Authorization:`Bearer ${session.access_token}`}, body:JSON.stringify(body) });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { show($("searchResult"), data.error || "Search could not be created.", "error"); return; }
  show($("searchResult"), `Search created securely. Search ID: ${data.search.id}. Payment required: ${data.amount} ${data.currency}.`, "success");
  $("searchForm").reset();
});

loadParks();
refreshAccount();
