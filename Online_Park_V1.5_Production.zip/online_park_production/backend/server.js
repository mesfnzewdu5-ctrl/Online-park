import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { initializeChapaPayment, verifyChapaPayment, verifyChapaWebhookSignature, generateTxRef, hashWebhookKey } from "./payment.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const app = express();
const PORT = Number(process.env.PORT || 3000);
const SUPABASE_URL = process.env.SUPABASE_URL;
const PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const PAYMENT_AMOUNT = Number(process.env.PAYMENT_AMOUNT_ETB || 10);
const PAYMENT_CURRENCY = process.env.PAYMENT_CURRENCY || "ETB";
const PUBLIC_BACKEND_URL = (process.env.PUBLIC_BACKEND_URL || `http://localhost:${PORT}`).replace(/\/+$/, "");
const PUBLIC_FRONTEND_URL = (process.env.PUBLIC_FRONTEND_URL || PUBLIC_BACKEND_URL).replace(/\/+$/, "");

if (!SUPABASE_URL || !PUBLISHABLE_KEY || !SERVICE_KEY) console.warn("Missing Supabase environment variables. Configure .env before production use.");
const admin = createClient(SUPABASE_URL || "https://invalid.local", SERVICE_KEY || "invalid", { auth:{autoRefreshToken:false,persistSession:false} });
const allowedOrigins = (process.env.CORS_ORIGINS || PUBLIC_FRONTEND_URL).split(",").map(s=>s.trim()).filter(Boolean);

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin(origin, cb){ if(!origin || allowedOrigins.includes(origin)) return cb(null,true); cb(new Error("CORS origin not allowed")); }, methods:["GET","POST"], allowedHeaders:["Content-Type","Authorization"] }));

// Runtime public configuration. These values are safe only when paired with correct RLS.
app.get("/config.js", (_req,res) => {
  res.type("application/javascript").send(`window.ONLINE_PARK_CONFIG=${JSON.stringify({supabaseUrl:SUPABASE_URL || "",supabasePublishableKey:PUBLISHABLE_KEY || ""})};`);
});

app.post("/api/payments/chapa/webhook", express.raw({type:"application/json",limit:"256kb"}), async (req,res)=>{
  try {
    const raw = Buffer.isBuffer(req.body) ? req.body : Buffer.from("");
    if (!verifyChapaWebhookSignature(raw, req.get("chapa-signature") || req.get("x-chapa-signature"))) return res.status(401).json({error:"Invalid webhook signature."});
    const event = JSON.parse(raw.toString("utf8"));
    const txRef = String(event?.tx_ref || "").trim();
    if (!txRef) return res.status(400).json({error:"Missing transaction reference."});
    const eventKey = hashWebhookKey(`chapa|${event?.event || "unknown"}|${txRef}|${event?.status || "unknown"}|${event?.updated_at || ""}`);
    const {error: insertError} = await admin.from("webhook_events").insert({event_key:eventKey,provider:"chapa",tx_ref:txRef,event_name:String(event?.event||"unknown"),payload_hash:crypto.createHash("sha256").update(raw).digest("hex")});
    if (insertError?.code === "23505") return res.json({received:true,duplicate:true});
    if (insertError) return res.status(500).json({error:"Webhook could not be recorded."});
    await finalizePayment(null, txRef);
    await admin.from("webhook_events").update({processed_at:new Date().toISOString()}).eq("event_key",eventKey);
    return res.json({received:true});
  } catch (e) { console.error(e.message); return res.status(500).json({error:"Webhook processing failed."}); }
});
app.use(express.json({limit:"64kb"}));
app.use(rateLimit({windowMs:60_000,limit:120,standardHeaders:true,legacyHeaders:false}));
const paymentLimiter = rateLimit({windowMs:60_000,limit:10,standardHeaders:true,legacyHeaders:false});

async function requireUser(req,res,next){
  try {
    const auth=req.get("authorization")||""; if(!auth.startsWith("Bearer ")) return res.status(401).json({error:"Authentication required."});
    const token=auth.slice(7).trim(); const {data,error}=await admin.auth.getUser(token);
    if(error || !data?.user) return res.status(401).json({error:"Invalid or expired session."}); req.user=data.user; next();
  } catch { res.status(401).json({error:"Authentication failed."}); }
}
const searchSchema=z.object({query:z.string().trim().min(1).max(200),park_id:z.string().uuid().optional()});
const paymentInitSchema=z.object({search_id:z.string().uuid()});
const verifySchema=z.object({tx_ref:z.string().regex(/^op_[a-f0-9-]{20,100}$/i)});

app.get("/api/health",(_req,res)=>res.json({ok:true,service:"online-park",version:"1.5.0"}));
app.post("/api/search",requireUser,async(req,res)=>{
  const parsed=searchSchema.safeParse(req.body); if(!parsed.success) return res.status(400).json({error:"Invalid search input."});
  const {data,error}=await admin.from("searches").insert({user_id:req.user.id,query:parsed.data.query,park_id:parsed.data.park_id||null}).select("id,query,park_id,created_at").single();
  if(error) return res.status(500).json({error:"Could not create search."});
  res.status(201).json({search:data,payment_required:true,amount:PAYMENT_AMOUNT,currency:PAYMENT_CURRENCY});
});
app.post("/api/payments/chapa/initialize",requireUser,paymentLimiter,async(req,res)=>{
  const parsed=paymentInitSchema.safeParse(req.body); if(!parsed.success) return res.status(400).json({error:"Invalid search_id."});
  const {data:search}=await admin.from("searches").select("id,query,user_id").eq("id",parsed.data.search_id).eq("user_id",req.user.id).maybeSingle();
  if(!search) return res.status(404).json({error:"Search not found."});
  const {data:existing}=await admin.from("payments").select("id,status,tx_ref").eq("search_id",search.id).eq("user_id",req.user.id).eq("provider","chapa").eq("status","SUCCESS").maybeSingle();
  if(existing) return res.status(409).json({error:"This search is already unlocked."});
  const txRef=generateTxRef();
  const {data:payment,error}=await admin.from("payments").insert({user_id:req.user.id,search_id:search.id,provider:"chapa",amount:PAYMENT_AMOUNT,expected_amount:PAYMENT_AMOUNT,currency:PAYMENT_CURRENCY,tx_ref:txRef,status:"PENDING"}).select("id,tx_ref,amount,currency,status").single();
  if(error) return res.status(500).json({error:"Could not create payment record."});
  try {
    const fullName=String(req.user.user_metadata?.full_name||"Online Park User").trim().split(/\s+/); const firstName=(fullName.shift()||"Online").slice(0,50); const lastName=(fullName.join(" ")||"Park").slice(0,50);
    const result=await initializeChapaPayment({amount:String(PAYMENT_AMOUNT),currency:PAYMENT_CURRENCY,email:req.user.email||"customer@example.com",first_name:firstName,last_name:lastName,tx_ref:txRef,callback_url:`${PUBLIC_BACKEND_URL}/api/payments/chapa/callback`,return_url:`${PUBLIC_FRONTEND_URL}/?payment=return&tx_ref=${encodeURIComponent(txRef)}`,customization:{title:"Online Park Search",description:`Search payment for ${search.query.slice(0,100)}`}});
    const checkoutUrl=result?.data?.checkout_url; if(!checkoutUrl) throw new Error("Payment provider did not return a checkout URL.");
    res.status(201).json({payment,checkout_url:checkoutUrl,tx_ref:txRef});
  } catch(e) { await admin.from("payments").update({status:"FAILED"}).eq("id",payment.id); res.status(502).json({error:"Payment provider initialization failed."}); }
});

async function finalizePayment(userId,txRef){
  const {data:payment}=await admin.from("payments").select("id,user_id,search_id,tx_ref,expected_amount,currency,status").eq("provider","chapa").eq("tx_ref",txRef).maybeSingle();
  if(!payment) throw Object.assign(new Error("Payment not found."),{status:404});
  if(userId && payment.user_id!==userId) throw Object.assign(new Error("Not authorized."),{status:403});
  if(payment.status==="SUCCESS") return {unlocked:true,status:"SUCCESS",search_id:payment.search_id,tx_ref:txRef};
  const verified=await verifyChapaPayment(txRef); const d=verified?.data||{}; const providerStatus=String(d.status||verified?.status||"").toLowerCase(); const amount=Number(d.amount); const currency=String(d.currency||"").toUpperCase(); const returnedRef=String(d.tx_ref||d.trx_ref||txRef);
  const valid=returnedRef===txRef && amount===Number(payment.expected_amount) && currency===String(payment.currency).toUpperCase();
  let status="PENDING"; if(providerStatus==="success"&&valid)status="SUCCESS"; else if(["failed","cancelled"].includes(providerStatus))status="FAILED"; else if(["refunded","refund"].includes(providerStatus))status="REFUNDED";
  const {error}=await admin.from("payments").update({status,provider_reference:String(d.reference||d.ref_id||""),verified_at:new Date().toISOString()}).eq("id",payment.id).neq("status","SUCCESS"); if(error) throw new Error("Could not finalize payment.");
  return {unlocked:status==="SUCCESS",status,search_id:payment.search_id,tx_ref:txRef};
}
app.post("/api/payments/chapa/verify",requireUser,paymentLimiter,async(req,res)=>{const p=verifySchema.safeParse(req.body);if(!p.success)return res.status(400).json({error:"Invalid transaction reference."});try{res.json(await finalizePayment(req.user.id,p.data.tx_ref));}catch(e){res.status(e.status||502).json({error:e.message||"Payment verification failed."});}});
app.get("/api/payments/chapa/callback",async(req,res)=>{const tx=String(req.query.tx_ref||req.query.trx_ref||"");if(!/^op_[a-f0-9-]{20,100}$/i.test(tx))return res.status(400).send("Invalid payment reference.");try{const r=await finalizePayment(null,tx);res.redirect(303,`${PUBLIC_FRONTEND_URL}/?payment=${r.unlocked?"success":"pending"}&tx_ref=${encodeURIComponent(tx)}`);}catch{res.redirect(303,`${PUBLIC_FRONTEND_URL}/?payment=error`);}});
app.get("/api/search/:id/access",requireUser,async(req,res)=>{if(!z.string().uuid().safeParse(req.params.id).success)return res.status(400).json({error:"Invalid search id."});const {data}=await admin.from("payments").select("search_id").eq("search_id",req.params.id).eq("user_id",req.user.id).eq("provider","chapa").eq("status","SUCCESS").maybeSingle();res.json({search_id:req.params.id,unlocked:Boolean(data)});});

app.use(express.static(path.join(root,"public"),{extensions:["html"]}));
app.get("*",(_req,res)=>res.sendFile(path.join(root,"public","index.html")));
app.use((err,_req,res,_next)=>{console.error(err.message);res.status(500).json({error:"Internal server error."});});
app.listen(PORT,()=>console.log(`Online Park V1.5 running on http://localhost:${PORT}`));
