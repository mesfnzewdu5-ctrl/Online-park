import crypto from "node:crypto";
const API_BASE=(process.env.CHAPA_API_BASE||"https://api.chapa.co").replace(/\/+$/,'');
const SECRET=process.env.CHAPA_SECRET_KEY||"";
function requireSecret(){if(!SECRET||SECRET.includes("REPLACE"))throw new Error("Payment provider secret is not configured.");}
async function request(path,options={}){requireSecret();const r=await fetch(`${API_BASE}${path}`,{...options,headers:{Authorization:`Bearer ${SECRET}`,"Content-Type":"application/json",...(options.headers||{})}});const raw=await r.text();let data;try{data=JSON.parse(raw)}catch{data={raw}}if(!r.ok){const e=new Error(data?.message||"Payment provider request failed");e.status=r.status;throw e}return data;}
export const initializeChapaPayment=(payload)=>request("/v1/transaction/initialize",{method:"POST",body:JSON.stringify(payload)});
export const verifyChapaPayment=(tx)=>request(`/v1/transaction/verify/${encodeURIComponent(tx)}`,{method:"GET"});
export function verifyChapaWebhookSignature(rawBody,received){const secret=process.env.CHAPA_WEBHOOK_SECRET||"";if(!secret||!received)return false;const expected=crypto.createHmac("sha256",secret).update(rawBody).digest("hex");const a=Buffer.from(expected,"utf8"),b=Buffer.from(String(received).trim().toLowerCase(),"utf8");return a.length===b.length&&crypto.timingSafeEqual(a,b)}
export const generateTxRef=()=>`op_${crypto.randomUUID()}`;
export const hashWebhookKey=(v)=>crypto.createHash("sha256").update(v).digest("hex");
