/*
 Online Park V1.3.2
 ACCOUNT SECURITY:
 - Only the Supabase publishable key belongs in the browser.
 - Never add service-role, payment, database-password, or AI secrets here.
*/
const PARKS = [
  {name:"Learning Park", icon:"📚", desc:"Learning spaces, study activities and skill discovery.", keywords:["learn","study","education","coding","skill"]},
  {name:"Recreation Park", icon:"🎮", desc:"Fun activities and relaxing virtual experiences.", keywords:["game","fun","music","movie","recreation"]},
  {name:"Culture Park", icon:"🌍", desc:"Discover languages, cultures, stories and traditions.", keywords:["culture","language","country","history","travel"]},
  {name:"Community Park", icon:"🤝", desc:"Connect around shared interests and communities.", keywords:["community","friends","connect","people","social"]}
];

const parkGrid = document.querySelector("#parkGrid");
parkGrid.innerHTML = PARKS.map(p => `
  <article class="card park">
    <div style="font-size:2rem">${p.icon}</div>
    <h3>${escapeHtml(p.name)}</h3>
    <p>${escapeHtml(p.desc)}</p>
  </article>`).join("");

document.querySelector("#searchForm").addEventListener("submit", async e => {
  e.preventDefault();
  const appetite = document.querySelector("#appetite").value.trim().toLowerCase();
  const match = PARKS.find(p => p.keywords.some(k => appetite.includes(k))) || PARKS[0];
  const result = document.querySelector("#searchResult");
  result.classList.remove("hidden");
  result.innerHTML = `<strong>${match.icon} ${escapeHtml(match.name)}</strong>
    <p>${escapeHtml(match.desc)}</p>
    <p>Demo recommendation. Authenticated server-side search will be added before paid search is enabled.</p>`;
});

async function accountReady() {
  if (typeof getCurrentUser !== "function") return;
  const user = await getCurrentUser();
  updateAccountUI(user);
}

function updateAccountUI(user) {
  const status = document.querySelector("#accountStatus");
  const logout = document.querySelector("#logoutBtn");
  if (user) {
    status.textContent = `Signed in as ${user.email}`;
    logout.classList.remove("hidden");
  } else {
    status.textContent = "Not signed in";
    logout.classList.add("hidden");
  }
}

document.querySelector("#signupForm").addEventListener("submit", async e => {
  e.preventDefault();
  const email = document.querySelector("#signupEmail").value.trim();
  const password = document.querySelector("#signupPassword").value;
  try {
    const {error} = await signUp(email, password);
    if (error) throw error;
    alert("Account created. Check your email to verify your account.");
  } catch (err) {
    alert("Sign-up error: " + safeError(err));
  }
});

document.querySelector("#loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const email = document.querySelector("#loginEmail").value.trim();
  const password = document.querySelector("#loginPassword").value;
  try {
    const {data, error} = await signIn(email, password);
    if (error) throw error;
    updateAccountUI(data.user);
    alert("Login successful.");
  } catch (err) {
    alert("Login error: " + safeError(err));
  }
});

document.querySelector("#logoutBtn").addEventListener("click", async () => {
  try {
    const {error} = await signOut();
    if (error) throw error;
    updateAccountUI(null);
  } catch (err) {
    alert("Logout error: " + safeError(err));
  }
});

const resetBox = document.createElement("div");
resetBox.className = "card";
resetBox.style.marginTop = "20px";
resetBox.innerHTML = `
  <h3>Password reset</h3>
  <p class="muted">We'll send a reset link to your email.</p>
  <input id="resetEmail" type="email" placeholder="Your account email">
  <button id="resetBtn" class="button" style="margin-top:10px">Send reset link</button>
`;
document.querySelector("#account").appendChild(resetBox);

document.querySelector("#resetBtn").addEventListener("click", async () => {
  const email = document.querySelector("#resetEmail").value.trim();
  if (!email) return alert("Enter your email.");
  try {
    const {error} = await sendPasswordReset(email);
    if (error) throw error;
    alert("If the account exists, a password-reset email has been requested.");
  } catch (err) {
    alert("Reset error: " + safeError(err));
  }
});

function safeError(err) {
  return String(err?.message || "Unknown error").slice(0, 180);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[ch]));
}

accountReady();
