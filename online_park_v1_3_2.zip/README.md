# Online Park V1.3.1 — Security Foundation

This version moves the project toward a real full-stack architecture.

## Included

- Responsive Online Park frontend
- Park catalog
- Personalized-search demo
- Authentication UI placeholders
- Supabase PostgreSQL schema
- Supabase Auth profile trigger
- Row Level Security policies
- Private user search records
- Private payment records
- Explicit protection against browser-side payment-success manipulation
- Server-only environment variable template

## Setup

1. Create a Supabase project.
2. Open Supabase SQL Editor.
3. Run `supabase/schema.sql`.
4. Configure Authentication as needed.
5. Later connect the frontend with the Supabase JavaScript client.
6. Put public configuration only where appropriate.
7. Keep service-role keys, AI keys and payment secrets on a server.
8. Add a backend API for AI and payment verification.

## Security warning

Do not put these in browser JavaScript:

- SUPABASE_SERVICE_ROLE_KEY
- OPENAI_API_KEY
- payment provider secret
- database password

The frontend is untrusted. Database RLS and backend authorization must enforce access.

## Current limitations

- Supabase is not connected to the browser yet.
- AI is not connected.
- Payment is not connected.
- No production deployment configuration is included.
- No real transaction is processed by this demo.

## Next version: V1.3.2

1. Connect Supabase Auth.
2. Implement signup/login/logout.
3. Load parks from PostgreSQL.
4. Create authenticated searches.
5. Add backend API.
6. Add server-side AI integration.
7. Add verified payment flow.
8. Add rate limiting and security logging.


## V1.3.2 account security implementation

The browser now has integration points for:
- Sign up
- Login
- Logout
- Current-session detection
- Password reset
- Email verification redirect

Before use:
1. Open `supabase/client.js`.
2. Replace only `YOUR_SUPABASE_PROJECT_URL`.
3. Replace only `YOUR_SUPABASE_PUBLISHABLE_KEY`.
4. Never put a service-role key in this file.
5. Run `supabase/schema.sql` in Supabase SQL Editor.
6. Enable email authentication in Supabase.
7. Test with a test account.

### Secrets that must remain server-side

Never put these in the frontend:
- service-role key
- database password
- payment provider secret
- CBE/bank credentials
- OpenAI API key

V1.3.3 will move sensitive operations behind a backend API.
