/*
 Online Park V1.3.2
 Only use the Supabase publishable/anon key in browser code.
 NEVER place the service-role key here.
*/
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_PUBLISHABLE_KEY = "YOUR_SUPABASE_PUBLISHABLE_KEY";

let supabaseClient = null;

async function loadSupabase() {
  if (SUPABASE_URL.startsWith("YOUR_") || SUPABASE_PUBLISHABLE_KEY.startsWith("YOUR_")) {
    return null;
  }

  if (!window.supabase) {
    await new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2";
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  supabaseClient = window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_PUBLISHABLE_KEY
  );
  return supabaseClient;
}

async function signUp(email, password) {
  const client = await loadSupabase();
  if (!client) throw new Error("Supabase is not configured.");
  return client.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: window.location.origin + window.location.pathname
    }
  });
}

async function signIn(email, password) {
  const client = await loadSupabase();
  if (!client) throw new Error("Supabase is not configured.");
  return client.auth.signInWithPassword({ email, password });
}

async function signOut() {
  const client = await loadSupabase();
  if (!client) throw new Error("Supabase is not configured.");
  return client.auth.signOut();
}

async function getCurrentUser() {
  const client = await loadSupabase();
  if (!client) return null;
  const { data, error } = await client.auth.getUser();
  if (error) return null;
  return data.user;
}

async function sendPasswordReset(email) {
  const client = await loadSupabase();
  if (!client) throw new Error("Supabase is not configured.");
  return client.auth.resetPasswordForEmail(email, {
    redirectTo: window.location.origin + window.location.pathname + "#reset"
  });
}
