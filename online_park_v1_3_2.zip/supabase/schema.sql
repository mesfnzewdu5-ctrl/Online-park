-- ONLINE PARK V1.3.1
-- Run this in the Supabase SQL Editor.
-- IMPORTANT: Review policies before production deployment.

create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (char_length(display_name) between 1 and 80),
  country text check (char_length(country) <= 80),
  language text check (char_length(language) <= 60),
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.parks (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null,
  category text not null,
  environment_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.activities (
  id uuid primary key default gen_random_uuid(),
  park_id uuid not null references public.parks(id) on delete cascade,
  name text not null,
  description text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.searches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  appetite text not null check (char_length(appetite) between 1 and 200),
  country text check (char_length(country) <= 80),
  language text check (char_length(language) <= 60),
  result_park_id uuid references public.parks(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  search_id uuid references public.searches(id) on delete set null,
  amount numeric(12,2) not null check (amount > 0),
  currency text not null default 'ETB',
  transaction_reference text unique,
  status text not null default 'PENDING'
    check (status in ('PENDING','SUCCESS','FAILED','REFUNDED')),
  created_at timestamptz not null default now(),
  verified_at timestamptz
);

-- Create profile automatically after signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id)
  values (new.id)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Enable Row Level Security.
alter table public.profiles enable row level security;
alter table public.parks enable row level security;
alter table public.activities enable row level security;
alter table public.searches enable row level security;
alter table public.payments enable row level security;

-- Profiles: users can access only their own profile.
drop policy if exists "profile_select_own" on public.profiles;
create policy "profile_select_own"
on public.profiles for select
to authenticated
using (auth.uid() = id);

drop policy if exists "profile_insert_own" on public.profiles;
create policy "profile_insert_own"
on public.profiles for insert
to authenticated
with check (auth.uid() = id);

drop policy if exists "profile_update_own" on public.profiles;
create policy "profile_update_own"
on public.profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

-- Parks and activities are public read-only catalog data.
drop policy if exists "parks_public_read" on public.parks;
create policy "parks_public_read"
on public.parks for select
to anon, authenticated
using (true);

drop policy if exists "activities_public_read" on public.activities;
create policy "activities_public_read"
on public.activities for select
to anon, authenticated
using (true);

-- Searches: a user can see/create only their own searches.
drop policy if exists "searches_select_own" on public.searches;
create policy "searches_select_own"
on public.searches for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "searches_insert_own" on public.searches;
create policy "searches_insert_own"
on public.searches for insert
to authenticated
with check (auth.uid() = user_id);

-- Payments: users can read their own payment records.
-- Production payment creation/verification should happen through a trusted backend.
drop policy if exists "payments_select_own" on public.payments;
create policy "payments_select_own"
on public.payments for select
to authenticated
using (auth.uid() = user_id);

-- Intentionally no client UPDATE policy for payment status.
-- The browser must never be allowed to mark a payment SUCCESS.
