// Browser helper. Private server secrets never belong here.
async function createSecureSearch(payload) {
  const user = await getCurrentUser();
  if (!user) throw new Error("Please log in first.");
  const client = await loadSupabase();
  const {data, error} = await client.auth.getSession();
  if (error || !data.session) throw new Error("Session expired. Please log in again.");

  const response = await fetch("http://localhost:3000/api/search", {
    method:"POST",
    headers:{
      "Content-Type":"application/json",
      "Authorization":`Bearer ${data.session.access_token}`
    },
    body:JSON.stringify(payload)
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Search request failed.");
  return result;
}
