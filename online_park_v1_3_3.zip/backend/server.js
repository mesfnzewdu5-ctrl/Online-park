import "dotenv/config";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5500", credentials: true }));
app.use(express.json({ limit: "20kb" }));

app.use("/api/", rateLimit({
  windowMs: 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false
}));

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { autoRefreshToken: false, persistSession: false } }
);

async function requireUser(req, res, next) {
  const header = req.headers.authorization || "";
  if (!header.startsWith("Bearer ")) return res.status(401).json({error:"Authentication required."});
  const { data, error } = await supabase.auth.getUser(header.slice(7));
  if (error || !data?.user) return res.status(401).json({error:"Invalid or expired session."});
  req.user = data.user;
  next();
}

const searchSchema = z.object({
  appetite: z.string().trim().min(1).max(200),
  country: z.string().trim().max(80).optional(),
  language: z.string().trim().max(60).optional()
});

app.get("/api/health", (_req, res) => res.json({ok:true, service:"online-park-api"}));

app.post("/api/search", requireUser, async (req, res) => {
  const parsed = searchSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:"Invalid search input."});

  const { appetite, country, language } = parsed.data;
  const { data, error } = await supabase.from("searches").insert({
    user_id: req.user.id, appetite, country: country || null, language: language || null
  }).select("id, created_at").single();

  if (error) {
    console.error("search insert failed", error);
    return res.status(500).json({error:"Could not create search."});
  }

  res.status(201).json({search_id:data.id, status:"PENDING_PAYMENT"});
});

app.use((err, _req, res, _next) => {
  console.error("Unhandled API error", err);
  res.status(500).json({error:"Internal server error."});
});

app.listen(Number(process.env.PORT || 3000), () =>
  console.log("Online Park API listening on port " + (process.env.PORT || 3000))
);
