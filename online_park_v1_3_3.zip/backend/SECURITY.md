# Online Park backend security

Never expose the Supabase service-role key, database password, payment provider secrets, bank/CBE credentials, or private AI keys.

Included:
- Helmet security headers
- CORS allowlist
- JSON body-size limit
- API rate limiting
- Bearer-token authentication
- Server-side Supabase user verification
- Zod input validation
- Generic client-facing errors

Before production:
- HTTPS only
- Real frontend origin
- Hosting-provider secret manager
- Stronger per-user/IP limits
- Audit logs
- Approved payment-provider verification
- Moderation and abuse controls
- Backups and tested deletion/retention procedures

Never accept payment success directly from the browser.
