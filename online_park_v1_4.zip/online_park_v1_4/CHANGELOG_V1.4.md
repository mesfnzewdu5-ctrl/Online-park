# Online Park V1.4

- Chapa sandbox initialization
- Server-fixed 10 ETB search price
- Server-side transaction verification
- HMAC webhook signature validation
- Webhook idempotency
- Payment/search ownership checks
- Search unlock only after verified SUCCESS
- Expanded payment schema
- Frontend API helper
- Security checklist
- No payment or bank secrets in frontend
