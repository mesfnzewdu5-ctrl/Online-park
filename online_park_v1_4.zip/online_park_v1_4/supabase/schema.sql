-- ONLINE PARK V1.4 DATABASE
create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  country text,
  language text,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.parks (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists public.activities (
  id uuid primary key default gen_random_uuid(),
  park_id uuid not null references public.parks(id) on delete cascade,
  name text not null,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists public.searches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  query text not null,
  park_id uuid references public.parks(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  search_id uuid not null references public.searches(id) on delete cascade,
  provider text not null default 'chapa',
  amount numeric(12,2) not null check (amount > 0),
  expected_amount numeric(12,2) not null check (expected_amount > 0),
  currency text not null default 'ETB',
  tx_ref text not null unique,
  provider_reference text,
  status text not null default 'PENDING'
    check (status in ('PENDING','SUCCESS','FAILED','REFUNDED')),
  created_at timestamptz not null default now(),
  verified_at timestamptz
);

create unique index if not exists payments_success_one_per_search
  on public.payments(search_id)
  where status = 'SUCCESS';

create table if not exists public.webhook_events (
  id uuid primary key default gen_random_uuid(),
  event_key text not null unique,
  provider text not null,
  tx_ref text not null,
  event_name text,
  payload_hash text not null,
  received_at timestamptz not null default now(),
  processed_at timestamptz
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.parks enable row level security;
alter table public.activities enable row level security;
alter table public.searches enable row level security;
alter table public.payments enable row level security;
alter table public.webhook_events enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (id = auth.uid());

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "parks_public_read" on public.parks;
create policy "parks_public_read" on public.parks
  for select to anon, authenticated using (true);

drop policy if exists "activities_public_read" on public.activities;
create policy "activities_public_read" on public.activities
  for select to anon, authenticated using (true);

drop policy if exists "searches_select_own" on public.searches;
create policy "searches_select_own" on public.searches
  for select to authenticated using (user_id = auth.uid());

drop policy if exists "payments_select_own" on public.payments;
create policy "payments_select_own" on public.payments
  for select to authenticated using (user_id = auth.uid());

-- No browser INSERT/UPDATE policy for payments.
-- No browser access to webhook_events.
-- Trusted backend performs payment mutations.
