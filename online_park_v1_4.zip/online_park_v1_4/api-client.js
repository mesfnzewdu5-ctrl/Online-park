// Online Park V1.4 API helper.
// Payment secrets remain on the backend.
const ONLINE_PARK_API = window.ONLINE_PARK_API || "http://localhost:3000";

async function onlineParkApi(path, options = {}) {
  const session = window.supabaseClient
    ? (await window.supabaseClient.auth.getSession()).data.session
    : null;

  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {})
  };

  if (session?.access_token) {
    headers.Authorization = `Bearer ${session.access_token}`;
  }

  const response = await fetch(`${ONLINE_PARK_API}${path}`, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "API request failed.");
  return data;
}

window.onlineParkApi = onlineParkApi;

window.initializeSearchPayment = (searchId) =>
  onlineParkApi("/api/payments/chapa/initialize", {
    method: "POST",
    body: JSON.stringify({ search_id: searchId })
  });

window.verifySearchPayment = (txRef) =>
  onlineParkApi("/api/payments/chapa/verify", {
    method: "POST",
    body: JSON.stringify({ tx_ref: txRef })
  });
