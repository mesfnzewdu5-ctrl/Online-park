# V1.4 Payment Security Checklist

- Chapa secret key is backend-only.
- Supabase service-role key is backend-only.
- Browser cannot set payment SUCCESS.
- Server fixes the search fee at 10 ETB.
- Webhook signature is validated before processing.
- Webhook events are idempotent.
- Chapa is queried again before a successful payment unlocks a search.
- tx_ref, amount, currency and provider status are checked.
- Search and payment ownership are checked.
- Production requires HTTPS, secret management, audit logging,
  monitoring, reconciliation/refunds, privacy/terms review, and security testing.
