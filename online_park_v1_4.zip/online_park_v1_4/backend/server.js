import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import crypto from "node:crypto";
import {
  initializeChapaPayment,
  verifyChapaPayment,
  verifyChapaWebhookSignature,
  generateTxRef,
  hashWebhookKey
} from "./payment.js";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const PAYMENT_AMOUNT = Number(process.env.PAYMENT_AMOUNT_ETB || 10);
const PAYMENT_CURRENCY = process.env.PAYMENT_CURRENCY || "ETB";
const PUBLIC_BACKEND_URL = (process.env.PUBLIC_BACKEND_URL || `http://localhost:${PORT}`).replace(/\/+$/, "");
const PUBLIC_FRONTEND_URL = (process.env.PUBLIC_FRONTEND_URL || "http://localhost:5500").replace(/\/+$/, "");

if (!SUPABASE_URL || !SERVICE_KEY) {
  console.warn("Supabase server credentials are not configured. Protected routes will fail safely.");
}

const supabase = createClient(SUPABASE_URL || "https://invalid.local", SERVICE_KEY || "invalid", {
  auth: { autoRefreshToken: false, persistSession: false }
});

const allowedOrigins = (process.env.CORS_ORIGINS || "http://localhost:5500")
  .split(",").map(s => s.trim()).filter(Boolean);

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("CORS origin not allowed"));
  },
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

// Webhook must receive the raw bytes BEFORE express.json().
app.post("/api/payments/chapa/webhook",
  express.raw({ type: "application/json", limit: "256kb" }),
  async (req, res) => {
    try {
      const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.from("");
      const signatureA = req.get("chapa-signature");
      const signatureB = req.get("x-chapa-signature");

      const valid = verifyChapaWebhookSignature(rawBody, signatureA) ||
                    verifyChapaWebhookSignature(rawBody, signatureB);

      if (!valid) return res.status(401).json({ error: "Invalid webhook signature." });

      let event;
      try {
        event = JSON.parse(rawBody.toString("utf8"));
      } catch {
        return res.status(400).json({ error: "Invalid JSON." });
      }

      const txRef = String(event?.tx_ref || "").trim();
      const eventName = String(event?.event || "unknown").trim();
      const status = String(event?.status || "unknown").trim().toLowerCase();

      if (!txRef) return res.status(400).json({ error: "Missing transaction reference." });

      // Idempotency key: the same event must never unlock the same search twice.
      const eventKey = hashWebhookKey(`chapa|${eventName}|${txRef}|${status}|${event?.updated_at || ""}`);

      const { data: inserted, error: eventInsertError } = await supabase
        .from("webhook_events")
        .insert({
          event_key: eventKey,
          provider: "chapa",
          tx_ref: txRef,
          event_name: eventName,
          payload_hash: crypto.createHash("sha256").update(rawBody).digest("hex")
        })
        .select("id")
        .maybeSingle();

      if (eventInsertError) {
        // Unique violation means this webhook was already processed.
        if (eventInsertError.code === "23505") return res.status(200).json({ received: true, duplicate: true });
        console.error("Webhook event storage failed:", eventInsertError.code);
        return res.status(500).json({ error: "Webhook could not be recorded." });
      }

      // Never trust webhook amount/status alone. Re-query Chapa.
      const verified = await verifyChapaPayment(txRef);
      const providerData = verified?.data || {};
      const verifiedStatus = String(providerData.status || verified?.status || "").toLowerCase();
      const verifiedAmount = Number(providerData.amount);
      const verifiedCurrency = String(providerData.currency || "").toUpperCase();
      const verifiedTxRef = String(providerData.tx_ref || providerData.trx_ref || txRef);

      const validTransaction =
        verifiedTxRef === txRef &&
        verifiedAmount === PAYMENT_AMOUNT &&
        verifiedCurrency === PAYMENT_CURRENCY;

      let newStatus = "PENDING";
      if (verifiedStatus === "success" && validTransaction) newStatus = "SUCCESS";
      else if (["failed", "cancelled"].includes(verifiedStatus)) newStatus = "FAILED";
      else if (["refunded", "refund"].includes(verifiedStatus)) newStatus = "REFUNDED";

      const update = {
        status: newStatus,
        provider_reference: String(providerData.reference || providerData.ref_id || ""),
        verified_at: new Date().toISOString()
      };

      const { error: updateError } = await supabase
        .from("payments")
        .update(update)
        .eq("provider", "chapa")
        .eq("tx_ref", txRef);

      if (updateError) {
        console.error("Payment update failed:", updateError.code);
        return res.status(500).json({ error: "Payment state could not be updated." });
      }

      console.info("Chapa webhook processed", { txRef, status: newStatus });
      return res.status(200).json({ received: true });
    } catch (error) {
      console.error("Webhook processing error:", error.message);
      return res.status(500).json({ error: "Webhook processing failed." });
    }
  }
);

app.use(express.json({ limit: "64kb" }));

const generalLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 100,
  standardHeaders: true,
  legacyHeaders: false
});

const paymentLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many payment requests. Please wait and try again." }
});

app.use(generalLimiter);

async function requireUser(req, res, next) {
  try {
    const auth = req.get("authorization") || "";
    if (!auth.startsWith("Bearer ")) return res.status(401).json({ error: "Authentication required." });

    const token = auth.slice(7).trim();
    if (!token) return res.status(401).json({ error: "Authentication required." });

    const { data, error } = await supabase.auth.getUser(token);
    if (error || !data?.user) return res.status(401).json({ error: "Invalid or expired session." });

    req.user = data.user;
    next();
  } catch {
    return res.status(401).json({ error: "Authentication failed." });
  }
}

const searchSchema = z.object({
  query: z.string().trim().min(1).max(200),
  park_id: z.string().uuid().optional()
});

const paymentInitSchema = z.object({
  search_id: z.string().uuid()
});

const verifySchema = z.object({
  tx_ref: z.string().regex(/^op_[a-f0-9-]{20,100}$/i)
});

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    service: "online-park-backend",
    version: "1.4.0",
    payment: "chapa-sandbox"
  });
});

app.post("/api/search", requireUser, async (req, res) => {
  const parsed = searchSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid search input." });

  const { data, error } = await supabase
    .from("searches")
    .insert({
      user_id: req.user.id,
      query: parsed.data.query,
      park_id: parsed.data.park_id || null
    })
    .select("id, query, park_id, created_at")
    .single();

  if (error) {
    console.error("Search insert failed:", error.code);
    return res.status(500).json({ error: "Could not create search." });
  }

  return res.status(201).json({
    search: data,
    payment_required: true,
    amount: PAYMENT_AMOUNT,
    currency: PAYMENT_CURRENCY
  });
});

app.post("/api/payments/chapa/initialize", requireUser, paymentLimiter, async (req, res) => {
  const parsed = paymentInitSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid search_id." });

  const searchId = parsed.data.search_id;

  const { data: search, error: searchError } = await supabase
    .from("searches")
    .select("id, query, user_id")
    .eq("id", searchId)
    .eq("user_id", req.user.id)
    .maybeSingle();

  if (searchError || !search) return res.status(404).json({ error: "Search not found." });

  const { data: existing } = await supabase
    .from("payments")
    .select("id, status, tx_ref")
    .eq("search_id", searchId)
    .eq("user_id", req.user.id)
    .eq("provider", "chapa")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (existing?.status === "SUCCESS") {
    return res.status(409).json({ error: "This search is already unlocked." });
  }

  const txRef = generateTxRef();

  const { data: payment, error: paymentError } = await supabase
    .from("payments")
    .insert({
      user_id: req.user.id,
      search_id: searchId,
      provider: "chapa",
      amount: PAYMENT_AMOUNT,
      expected_amount: PAYMENT_AMOUNT,
      currency: PAYMENT_CURRENCY,
      tx_ref: txRef,
      status: "PENDING"
    })
    .select("id, tx_ref, amount, currency, status")
    .single();

  if (paymentError) {
    console.error("Payment creation failed:", paymentError.code);
    return res.status(500).json({ error: "Could not create payment record." });
  }

  try {
    const email = req.user.email || "customer@onlinepark.local";
    const name = String(req.user.user_metadata?.full_name || "Online Park User").trim();
    const parts = name.split(/\s+/);
    const firstName = (parts.shift() || "Online").slice(0, 50);
    const lastName = (parts.join(" ") || "Park").slice(0, 50);

    const result = await initializeChapaPayment({
      amount: String(PAYMENT_AMOUNT),
      currency: PAYMENT_CURRENCY,
      email,
      first_name: firstName,
      last_name: lastName,
      tx_ref: txRef,
      callback_url: `${PUBLIC_BACKEND_URL}/api/payments/chapa/callback`,
      return_url: `${PUBLIC_FRONTEND_URL}/?payment=return&tx_ref=${encodeURIComponent(txRef)}`,
      customization: {
        title: "Online Park Search",
        description: `Search payment for ${String(search.query).slice(0, 100)}`
      }
    });

    const checkoutUrl = result?.data?.checkout_url;
    if (!checkoutUrl) throw new Error("Chapa did not return a checkout URL.");

    return res.status(201).json({
      payment,
      checkout_url: checkoutUrl,
      tx_ref: txRef
    });
  } catch (error) {
    await supabase.from("payments")
      .update({ status: "FAILED" })
      .eq("id", payment.id);

    console.error("Chapa initialization failed:", error.message);
    return res.status(502).json({ error: "Payment provider initialization failed." });
  }
});

async function verifyAndFinalizePayment(reqUserId, txRef) {
  const { data: payment, error: paymentError } = await supabase
    .from("payments")
    .select("id, user_id, search_id, tx_ref, amount, expected_amount, currency, status")
    .eq("tx_ref", txRef)
    .eq("provider", "chapa")
    .maybeSingle();

  if (paymentError || !payment) throw Object.assign(new Error("Payment not found."), { status: 404 });
  if (reqUserId && payment.user_id !== reqUserId) throw Object.assign(new Error("Not authorized."), { status: 403 });

  if (payment.status === "SUCCESS") {
    return { unlocked: true, status: "SUCCESS", search_id: payment.search_id, tx_ref: payment.tx_ref };
  }

  const verified = await verifyChapaPayment(txRef);
  const providerData = verified?.data || {};
  const providerStatus = String(providerData.status || verified?.status || "").toLowerCase();
  const providerAmount = Number(providerData.amount);
  const providerCurrency = String(providerData.currency || "").toUpperCase();
  const providerTxRef = String(providerData.tx_ref || providerData.trx_ref || txRef);

  const valid =
    providerTxRef === payment.tx_ref &&
    providerAmount === Number(payment.expected_amount) &&
    providerCurrency === payment.currency;

  let status = "PENDING";
  if (providerStatus === "success" && valid) status = "SUCCESS";
  else if (["failed", "cancelled"].includes(providerStatus)) status = "FAILED";
  else if (["refunded", "refund"].includes(providerStatus)) status = "REFUNDED";

  const { error: updateError } = await supabase
    .from("payments")
    .update({
      status,
      provider_reference: String(providerData.reference || providerData.ref_id || ""),
      verified_at: new Date().toISOString()
    })
    .eq("id", payment.id)
    .neq("status", "SUCCESS");

  if (updateError) throw new Error("Could not finalize payment.");

  return {
    unlocked: status === "SUCCESS",
    status,
    search_id: payment.search_id,
    tx_ref: payment.tx_ref
  };
}

app.post("/api/payments/chapa/verify", requireUser, paymentLimiter, async (req, res) => {
  const parsed = verifySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid transaction reference." });

  try {
    const result = await verifyAndFinalizePayment(req.user.id, parsed.data.tx_ref);
    return res.json(result);
  } catch (error) {
    return res.status(error.status || 502).json({ error: error.message || "Payment verification failed." });
  }
});

app.get("/api/payments/chapa/callback", async (req, res) => {
  const txRef = String(req.query.tx_ref || req.query.trx_ref || "").trim();
  if (!/^op_[a-f0-9-]{20,100}$/i.test(txRef)) {
    return res.status(400).send("Invalid payment reference.");
  }

  try {
    // Callback parameters are informational only; verification comes from Chapa API.
    const result = await verifyAndFinalizePayment(null, txRef);
    const target = `${PUBLIC_FRONTEND_URL}/?payment=${result.unlocked ? "success" : "pending"}&tx_ref=${encodeURIComponent(txRef)}`;
    return res.redirect(303, target);
  } catch (error) {
    console.error("Callback verification failed:", error.message);
    return res.redirect(303, `${PUBLIC_FRONTEND_URL}/?payment=error`);
  }
});

app.get("/api/search/:id/access", requireUser, async (req, res) => {
  const idSchema = z.string().uuid().safeParse(req.params.id);
  if (!idSchema.success) return res.status(400).json({ error: "Invalid search id." });

  const { data: payment } = await supabase
    .from("payments")
    .select("status, search_id")
    .eq("search_id", idSchema.data)
    .eq("user_id", req.user.id)
    .eq("provider", "chapa")
    .eq("status", "SUCCESS")
    .maybeSingle();

  return res.json({
    search_id: idSchema.data,
    unlocked: Boolean(payment)
  });
});

app.use((err, req, res, next) => {
  console.error("Unhandled error:", err.message);
  return res.status(500).json({ error: "Internal server error." });
});

app.listen(PORT, () => {
  console.log(`Online Park backend v1.4 listening on http://localhost:${PORT}`);
});
