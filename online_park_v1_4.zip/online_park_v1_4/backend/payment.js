import crypto from "node:crypto";

const API_BASE = (process.env.CHAPA_API_BASE || "https://api.chapa.co").replace(/\/+$/, "");
const SECRET = process.env.CHAPA_SECRET_KEY || "";

function requireChapaSecret() {
  if (!SECRET || SECRET.includes("REPLACE_ME")) {
    throw new Error("Chapa server secret is not configured.");
  }
}

async function chapaFetch(path, options = {}) {
  requireChapaSecret();
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Authorization": `Bearer ${SECRET}`,
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  const raw = await response.text();
  let data;
  try { data = JSON.parse(raw); } catch { data = { raw }; }

  if (!response.ok) {
    const message = data?.message || "Chapa API request failed";
    const error = new Error(message);
    error.status = response.status;
    error.providerData = data;
    throw error;
  }
  return data;
}

export async function initializeChapaPayment(payload) {
  return chapaFetch("/v1/transaction/initialize", {
    method: "POST",
    body: JSON.stringify(payload)
  });
}

export async function verifyChapaPayment(txRef) {
  return chapaFetch(`/v1/transaction/verify/${encodeURIComponent(txRef)}`, {
    method: "GET"
  });
}

function safeEqualHex(a, b) {
  if (!a || !b || typeof a !== "string" || typeof b !== "string") return false;
  const aa = Buffer.from(a.trim().toLowerCase(), "utf8");
  const bb = Buffer.from(b.trim().toLowerCase(), "utf8");
  if (aa.length !== bb.length) return false;
  return crypto.timingSafeEqual(aa, bb);
}

export function verifyChapaWebhookSignature(rawBody, receivedSignature) {
  const secret = process.env.CHAPA_WEBHOOK_SECRET || "";
  if (!secret || !receivedSignature) return false;

  const expected = crypto
    .createHmac("sha256", secret)
    .update(rawBody)
    .digest("hex");

  return safeEqualHex(expected, receivedSignature);
}

export function generateTxRef() {
  return `op_${crypto.randomUUID()}`;
}

export function hashWebhookKey(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}
